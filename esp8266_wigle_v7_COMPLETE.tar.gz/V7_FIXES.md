# Version 7 - Fixed Timestamp and SSID Parsing

## 🐛 Bugs Fixed from V6

### Bug 1: All Probes Show Same Timestamp
**Problem**: Every probe showed the same "first seen" time instead of individual capture times.

**Root Cause**: `startTime` was set once at device boot and never reset when entering sniffing mode. All timestamps were calculated as `millis() - startTime`, which gave the same relative time for probes captured in the same session.

**Fix**:
```cpp
void startSniffingMode() {
  // ... existing code ...
  isSniffing = true;
  sniffingStartTime = millis();
  startTime = millis();  // ← NEW: Reset for accurate probe timestamps
}
```

Now each sniffing session resets `startTime`, so timestamps show actual capture time relative to when sniffing started.

### Bug 2: All SSIDs Show as `<broadcast>`
**Problem**: Dashboard only showed `<broadcast>` for all probes, never actual SSIDs like "HomeNetwork" or "CoffeeShop".

**Root Cause**: V6's SSID parsing used a `while` loop to search for SSID tag, but the loop logic was incorrect and often failed to find the tag at offset 24.

**Fix**: Simplified SSID parsing - directly check offset 24 (where SSID tag should be in probe requests):

```cpp
// V6 (Broken):
int offset = 24;
while (offset + 2 < length) {
  uint8_t tagNumber = snifferPacket->data[offset];
  // ... complex loop logic that often failed
}

// V7 (Fixed):
if (length > 25) {
  uint8_t tagNumber = snifferPacket->data[24];  // Direct access
  uint8_t tagLength = snifferPacket->data[25];
  
  if (tagNumber == 0 && tagLength > 0 && tagLength <= 32) {
    // Parse SSID directly from offset 26
  }
}
```

**Additional Validation**: Added printable character check to filter out garbage SSIDs:
```cpp
// Validate SSID contains printable characters (ASCII 32-126)
bool validSSID = true;
for (int i = 0; i < ssidLen; i++) {
  if (ssidBuf[i] < 32 || ssidBuf[i] > 126) {
    validSSID = false;
    break;
  }
}
```

## ✅ What's Fixed in V7

| Issue | V6 | V7 |
|-------|----|----|
| **Timestamps** | All same time | Individual capture times |
| **SSID Parsing** | Always `<broadcast>` | Actual SSIDs shown |
| **SSID Validation** | None | Printable char check |

## 📊 Expected Output

### Serial Monitor (V7)
```
PROBE: A4:83:E7:12:34:56 -> HomeNetwork (RSSI: -45 dBm, CH: 6)
PROBE: B8:27:EB:AB:CD:EF -> CoffeeShop (RSSI: -67 dBm, CH: 1)
PROBE: C0:FF:EE:11:22:33 -> <broadcast> (RSSI: -52 dBm, CH: 11)
PROBE: D4:12:43:AB:CD:EF -> MyPhone5G (RSSI: -38 dBm, CH: 6)
```

### Dashboard (V7)
```
┌────────────────────────────────────────────────────────┐
│ Time  | MAC Address       | SSID        | RSSI | CH   │
├────────────────────────────────────────────────────────┤
│ 0m 5s | A4:83:E7:12:34:56 | HomeNetwork | -45  | 6    │
│ 0m 8s | B8:27:EB:AB:CD:EF | CoffeeShop  | -67  | 1    │
│ 0m 12s| C0:FF:EE:11:22:33 | <broadcast> | -52  | 11   │
│ 0m 15s| D4:12:43:AB:CD:EF | MyPhone5G   | -38  | 6    │
│ 0m 18s| E8:9F:6D:12:34:56 | OfficeWiFi  | -71  | 3    │
└────────────────────────────────────────────────────────┘
```

Notice:
- ✅ **Different timestamps** for each probe (0m 5s, 0m 8s, 0m 12s, etc.)
- ✅ **Actual SSIDs** displayed ("HomeNetwork", "CoffeeShop", "MyPhone5G")
- ✅ **Mix of directed and broadcast** probes

## 🎯 What You Should See

### Directed Probes (with SSID)
Devices actively looking for specific networks they've connected to before:
- "HomeNetwork" - Someone's home WiFi
- "CoffeeShop" - Public WiFi
- "OfficeWiFi" - Corporate network
- "iPhone" - Personal hotspot

### Broadcast Probes (no SSID)
Devices scanning for any available network:
- `<broadcast>` - Modern privacy-conscious devices
- Common on iOS 14+, Android 10+

## 🔍 Technical Details

### Probe Request Frame Structure
```
Offset | Size | Field
-------|------|------------------
0      | 2    | Frame Control
2      | 2    | Duration
4      | 6    | Destination Address (broadcast FF:FF:FF:FF:FF:FF)
10     | 6    | Source Address (device MAC)
16     | 6    | BSSID (broadcast FF:FF:FF:FF:FF:FF)
22     | 2    | Sequence Control
24     | 1    | Tag Number (0 = SSID)
25     | 1    | Tag Length (SSID length)
26     | var  | SSID (actual network name)
```

V7 correctly parses this structure, reading:
- Tag Number at offset 24 (should be 0 for SSID)
- Tag Length at offset 25 (SSID string length)
- SSID data starting at offset 26

### Timestamp Calculation
```cpp
// When probe is captured:
probeList[probeCount].timestamp = millis() - startTime;

// startTime is reset when sniffing mode starts:
startTime = millis();

// Result: timestamp = milliseconds since sniffing started
// Displayed as: "2m 15s" (2 minutes 15 seconds ago)
```

## 🚀 Testing V7

1. **Flash V7** firmware
2. **Start sniffing** for 5 minutes
3. **Check serial monitor**:
   - Should see actual SSIDs (not all `<broadcast>`)
   - Should see mix of network names
4. **Reconnect to dashboard**:
   - Each probe should have different timestamp
   - SSIDs should be displayed correctly
   - Should see actual network names

## ✅ Success Criteria

V7 is working when you see:

✅ **Varying timestamps**: 0m 5s, 0m 12s, 1m 3s, etc. (not all the same)  
✅ **Actual SSIDs**: "HomeNetwork", "CoffeeShop", etc. (not all `<broadcast>`)  
✅ **Mix of directed and broadcast**: Some with SSIDs, some `<broadcast>`  
✅ **Different MACs**: Multiple unique device addresses  
✅ **Printable SSIDs**: No garbage characters  

---

**V7 fixes both critical bugs - timestamps now show individual capture times and SSIDs are properly parsed and displayed!** 🎉
