#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <EEPROM.h>

extern "C" {
  #include <user_interface.h>
}

// ===== EEPROM CONFIGURATION =====
#define EEPROM_SIZE 512
#define EEPROM_MAGIC 0xAB  // Magic byte to check if EEPROM is initialized

struct Config {
  uint8_t magic;
  char wifi_ssid[64];
  char wifi_password[64];
  char ap_ssid[32];
  char ap_password[32];
  char wigle_api_name[64];
  char wigle_api_token[64];
  bool configured;
};

Config config;

// ===== DEFAULT SETTINGS =====
const char* DEFAULT_AP_SSID = "ESP8266-Setup";
const char* DEFAULT_AP_PASSWORD = "setup123";
const int MAX_RECORDS_BEFORE_UPLOAD = 100;
const int CHANNEL_HOP_INTERVAL = 500;  // Slower hopping = better capture

// ===== CONSTANTS =====
#define DATA_LENGTH 112
#define TYPE_MANAGEMENT 0x00
#define SUBTYPE_PROBE_REQUEST 0x04
#define MAX_PROBES_DISPLAY 200

// ===== STRUCTURES =====
struct RxControl {
  signed rssi:8;
  unsigned rate:4;
  unsigned is_group:1;
  unsigned:1;
  unsigned sig_mode:2;
  unsigned legacy_length:12;
  unsigned damatch0:1;
  unsigned damatch1:1;
  unsigned bssidmatch0:1;
  unsigned bssidmatch1:1;
  unsigned MCS:7;
  unsigned CWB:1;
  unsigned HT_length:16;
  unsigned Smoothing:1;
  unsigned Not_Sounding:1;
  unsigned:1;
  unsigned Aggregation:1;
  unsigned STBC:2;
  unsigned FEC_CODING:1;
  unsigned SGI:1;
  unsigned rxend_state:8;
  unsigned ampdu_cnt:8;
  unsigned channel:4;
  unsigned:12;
};

struct SnifferPacket {
  struct RxControl rx_ctrl;
  uint8_t data[DATA_LENGTH];
  uint16_t cnt;
  uint16_t len;
};

struct ProbeRequest {
  String mac;
  String ssid;
  int rssi;
  int channel;
  unsigned long timestamp;
};

// ===== GLOBAL VARIABLES =====
ProbeRequest probeList[MAX_PROBES_DISPLAY];
int probeCount = 0;
int totalProbesCapture = 0;
int uploadedCount = 0;
unsigned long lastChannelHop = 0;
int currentChannel = 1;
bool wifiConnected = false;
String lastUploadStatus = "Not uploaded yet";
unsigned long startTime = 0;
bool setupMode = false;
unsigned long lastAPCheck = 0;
bool isSniffing = false;
unsigned long sniffingStartTime = 0;
int sniffingDuration = 300;  // Default 5 minutes in seconds

ESP8266WebServer server(80);

// ===== FUNCTION DECLARATIONS =====
void loadConfig();
void saveConfig();
void resetConfig();
bool connectToWiFi();
void disconnectWiFi();
void uploadToWiGLE();
void snifferCallback(uint8_t *buffer, uint16_t length);
void hopChannel();
String macToString(const uint8_t* mac);
void addProbe(const String& mac, const String& ssid, int rssi, int channel);
String generateCSV();
String base64Encode(const String& input);
void handleRoot();
void handleData();
void handleUpload();
void handleClear();
void handleSetup();
void handleSaveConfig();
void handleReset();
void handleStartSniffing();
void handleStopSniffing();
void handleStatus();
void setupWebServer();
void startSniffingMode();
void stopSniffingMode();
void startDashboardMode();
void enableProbeCapture();
void disableProbeCapture();

// ===== SETUP =====
void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n\n=================================");
  Serial.println("ESP8266 WiGLE Probe Sniffer");
  Serial.println("Web Config Version");
  Serial.println("=================================\n");
  
  // Initialize EEPROM
  EEPROM.begin(EEPROM_SIZE);
  loadConfig();
  
  startTime = millis();
  
  // Check if device is configured
  if (!config.configured) {
    Serial.println("⚠️  Device not configured!");
    Serial.println("Starting in SETUP MODE...\n");
    setupMode = true;
    
    // Create setup AP
    WiFi.disconnect(true);
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_OFF);
    delay(500);
    WiFi.mode(WIFI_AP);
    delay(500);
    WiFi.softAP(DEFAULT_AP_SSID, DEFAULT_AP_PASSWORD, 6, false, 4);
    delay(1000);
    
    IPAddress apIP = WiFi.softAPIP();
    Serial.println("Setup Access Point started!");
    Serial.print("SSID: ");
    Serial.println(DEFAULT_AP_SSID);
    Serial.print("Password: ");
    Serial.println(DEFAULT_AP_PASSWORD);
    Serial.print("IP: ");
    Serial.println(apIP);
    Serial.println("\n📱 Connect to this WiFi and visit: http://" + apIP.toString());
    Serial.println("   Configure your settings, then the device will restart.\n");
    
    setupWebServer();
    server.begin();
    
  } else {
    Serial.println("✅ Device configured!");
    Serial.println("Starting in NORMAL MODE...\n");
    setupMode = false;
    
    // Set up Access Point for web interface
    Serial.println("Configuring Access Point...");
    
    // Stop any sniffing first
    wifi_promiscuous_enable(0);
    
    // Completely reset WiFi
    WiFi.disconnect(true);
    WiFi.softAPdisconnect(true);
    WiFi.mode(WIFI_OFF);
    delay(1000);
    
    // Set to AP-only mode (not AP+STA to avoid conflicts)
    WiFi.mode(WIFI_AP);
    delay(1000);
    
    // Configure AP with explicit parameters
    // Channel 6 is most compatible, hidden=false (0), max 4 connections
    Serial.print("Starting AP with SSID: ");
    Serial.println(config.ap_ssid);
    
    bool apStarted = WiFi.softAP(config.ap_ssid, config.ap_password, 6, false, 4);
    delay(1000);
    
    if (!apStarted) {
      Serial.println("⚠️  First attempt failed, retrying...");
      WiFi.softAPdisconnect(true);
      delay(500);
      apStarted = WiFi.softAP(config.ap_ssid, config.ap_password, 6, false, 4);
      delay(1000);
    }
    
    // Verify AP is running
    IPAddress apIP = WiFi.softAPIP();
    uint8_t stationCount = WiFi.softAPgetStationNum();
    
    Serial.println("\n=== Access Point Status ===");
    Serial.print("AP Started: ");
    Serial.println(apStarted ? "YES" : "NO");
    Serial.print("AP SSID: ");
    Serial.println(config.ap_ssid);
    Serial.print("AP Password: ");
    Serial.println(config.ap_password);
    Serial.print("AP IP: ");
    Serial.println(apIP);
    Serial.print("AP Channel: 6");
    Serial.println();
    Serial.print("AP Hidden: false");
    Serial.println();
    Serial.print("Connected Stations: ");
    Serial.println(stationCount);
    Serial.println("===========================\n");
    
    if (apIP == IPAddress(0, 0, 0, 0)) {
      Serial.println("⚠️  WARNING: AP IP is 0.0.0.0 - AP may not be working!");
    }
    
    Serial.println("📱 Connect to the AP and visit: http://" + apIP.toString());
    Serial.println();
    
    setupWebServer();
    server.begin();
    Serial.println("Web server started!");
    Serial.println("\n=== DASHBOARD MODE ===");
    Serial.println("Ready to capture probes.");
    Serial.println("Click 'Start Sniffing' in the web interface to begin.\n");
  }
}

// ===== MAIN LOOP =====
void loop() {
  unsigned long currentTime = millis();
  
  if (setupMode) {
    // Setup mode - just handle web server
    server.handleClient();
  }
  else if (isSniffing) {
    // Sniffing mode - no web server, just capture
    
    // Channel hopping
    if (currentTime - lastChannelHop >= CHANNEL_HOP_INTERVAL) {
      hopChannel();
      lastChannelHop = currentTime;
    }
    
    // Check if sniffing duration expired
    if (sniffingDuration > 0 && (currentTime - sniffingStartTime) / 1000 >= sniffingDuration) {
      Serial.println("\nSniffing duration completed. Returning to dashboard mode...");
      stopSniffingMode();
      startDashboardMode();
    }
  }
  else {
    // Dashboard mode - handle web server, no sniffing
    server.handleClient();
    
    // Periodic AP status check (every 30 seconds)
    if (currentTime - lastAPCheck >= 30000) {
      IPAddress apIP = WiFi.softAPIP();
      if (apIP == IPAddress(0, 0, 0, 0)) {
        Serial.println("⚠️  AP appears to be down! Attempting restart...");
        startDashboardMode();  // Recreate AP
      }
      lastAPCheck = currentTime;
    }
  }
  
  delay(1);
}

// ===== CONFIG MANAGEMENT =====
void loadConfig() {
  EEPROM.get(0, config);
  
  // Check if EEPROM is initialized
  if (config.magic != EEPROM_MAGIC) {
    Serial.println("EEPROM not initialized, using defaults...");
    resetConfig();
  } else {
    Serial.println("Configuration loaded from EEPROM");
  }
}

void saveConfig() {
  config.magic = EEPROM_MAGIC;
  EEPROM.put(0, config);
  EEPROM.commit();
  Serial.println("Configuration saved to EEPROM");
}

void resetConfig() {
  memset(&config, 0, sizeof(Config));
  config.magic = EEPROM_MAGIC;
  config.configured = false;
  strcpy(config.ap_ssid, DEFAULT_AP_SSID);
  strcpy(config.ap_password, DEFAULT_AP_PASSWORD);
  saveConfig();
}

// ===== MODE CONTROL =====
void startDashboardMode() {
  Serial.println("\n=== Starting Dashboard Mode ===");
  
  // Disable sniffing
  disableProbeCapture();
  
  // Reset WiFi
  WiFi.disconnect(true);
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(1000);
  
  // Create AP
  WiFi.mode(WIFI_AP);
  delay(1000);
  
  bool apStarted = WiFi.softAP(config.ap_ssid, config.ap_password, 6, false, 4);
  delay(1000);
  
  if (!apStarted) {
    Serial.println("⚠️  First attempt failed, retrying...");
    WiFi.softAPdisconnect(true);
    delay(500);
    WiFi.softAP(config.ap_ssid, config.ap_password, 6, false, 4);
    delay(1000);
  }
  
  IPAddress apIP = WiFi.softAPIP();
  Serial.print("AP Started: ");
  Serial.println(apStarted ? "YES" : "NO");
  Serial.print("AP IP: ");
  Serial.println(apIP);
  
  // Restart web server
  server.begin();
  Serial.println("Web server started!");
  Serial.println("📱 Connect to AP and visit: http://" + apIP.toString());
  Serial.println("=== Dashboard Mode Active ===\n");
  
  isSniffing = false;
}

void startSniffingMode() {
  Serial.println("\n=== Starting Sniffing Mode ===");
  Serial.println("Shutting down AP and web server...");
  
  // Stop web server
  server.stop();
  server.close();
  
  // Shutdown AP
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(1000);
  
  // Set to station mode for sniffing
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(1000);
  
  // Enable probe capture
  enableProbeCapture();
  
  isSniffing = true;
  sniffingStartTime = millis();
  startTime = millis();  // Reset startTime for accurate probe timestamps
  
  Serial.println("=== Sniffing Mode Active ===");
  Serial.print("Duration: ");
  if (sniffingDuration > 0) {
    Serial.print(sniffingDuration);
    Serial.println(" seconds");
  } else {
    Serial.println("Unlimited (manual stop required)");
  }
  Serial.println("Capturing probe requests...\n");
}

void stopSniffingMode() {
  Serial.println("\nStopping sniffing mode...");
  disableProbeCapture();
  isSniffing = false;
}

void enableProbeCapture() {
  wifi_set_opmode(STATION_MODE);
  wifi_set_channel(currentChannel);
  wifi_promiscuous_enable(0);
  delay(100);
  wifi_set_promiscuous_rx_cb(snifferCallback);
  wifi_promiscuous_enable(1);
  Serial.println("Probe capture enabled.");
}

void disableProbeCapture() {
  wifi_promiscuous_enable(0);
  Serial.println("Probe capture disabled.");
}

// ===== WEB SERVER HANDLERS =====
void setupWebServer() {
  server.on("/", handleRoot);
  server.on("/data", handleData);
  server.on("/upload", handleUpload);
  server.on("/clear", handleClear);
  server.on("/setup", handleSetup);
  server.on("/save", HTTP_POST, handleSaveConfig);
  server.on("/reset", handleReset);
  server.on("/startsniff", handleStartSniffing);
  server.on("/stopsniff", handleStopSniffing);
  server.on("/status", handleStatus);
}

void handleRoot() {
  if (setupMode) {
    handleSetup();
    return;
  }
  
  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>ESP8266 Probe Sniffer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background: #1a1a1a;
      color: #e0e0e0;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
    }
    h1 {
      color: #4CAF50;
      text-align: center;
      margin-bottom: 10px;
    }
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      margin-bottom: 20px;
    }
    .stat-box {
      background: #2d2d2d;
      padding: 15px;
      border-radius: 8px;
      border-left: 4px solid #4CAF50;
    }
    .stat-label {
      font-size: 12px;
      color: #888;
      text-transform: uppercase;
    }
    .stat-value {
      font-size: 24px;
      font-weight: bold;
      color: #4CAF50;
      margin-top: 5px;
    }
    .controls {
      margin-bottom: 20px;
      text-align: center;
    }
    button {
      background: #4CAF50;
      color: white;
      border: none;
      padding: 12px 24px;
      margin: 5px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
    }
    button:hover {
      background: #45a049;
    }
    button.danger {
      background: #f44336;
    }
    button.danger:hover {
      background: #da190b;
    }
    button.warning {
      background: #ff9800;
    }
    button.warning:hover {
      background: #e68900;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: #2d2d2d;
      border-radius: 8px;
      overflow: hidden;
    }
    th {
      background: #3d3d3d;
      padding: 12px;
      text-align: left;
      color: #4CAF50;
      font-weight: bold;
    }
    td {
      padding: 10px 12px;
      border-bottom: 1px solid #3d3d3d;
    }
    tr:hover {
      background: #353535;
    }
    .mac {
      font-family: monospace;
      color: #64B5F6;
    }
    .ssid {
      color: #FFD54F;
      font-weight: bold;
    }
    .rssi {
      font-weight: bold;
    }
    .rssi-good {
      color: #4CAF50;
    }
    .rssi-medium {
      color: #FFA726;
    }
    .rssi-poor {
      color: #EF5350;
    }
    .status {
      padding: 10px;
      margin-bottom: 20px;
      border-radius: 5px;
      background: #2d2d2d;
      border-left: 4px solid #2196F3;
    }
    .auto-refresh {
      text-align: center;
      margin-bottom: 10px;
      color: #888;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>📡 ESP8266 Probe Request Sniffer</h1>
    
    <div class="stats">
      <div class="stat-box">
        <div class="stat-label">Total Captured</div>
        <div class="stat-value" id="totalProbes">0</div>
      </div>
      <div class="stat-box">
        <div class="stat-label">In Memory</div>
        <div class="stat-value" id="memoryProbes">0</div>
      </div>
      <div class="stat-box">
        <div class="stat-label">Uploaded</div>
        <div class="stat-value" id="uploaded">0</div>
      </div>
      <div class="stat-box">
        <div class="stat-label">Current Channel</div>
        <div class="stat-value" id="channel">1</div>
      </div>
      <div class="stat-box">
        <div class="stat-label">Uptime</div>
        <div class="stat-value" id="uptime">0s</div>
      </div>
    </div>

    <div class="status" id="uploadStatus">
      Last Upload: <span id="lastUpload">Not uploaded yet</span>
    </div>

    <div class="status" id="modeStatus" style="border-left: 4px solid #2196F3;">
      <strong>Mode:</strong> <span id="currentMode">Dashboard (Not Sniffing)</span>
    </div>

    <div class="controls">
      <button id="sniffButton" onclick="toggleSniffing()" style="background: #2196F3; font-size: 16px; padding: 15px 30px;">▶️ START SNIFFING</button>
    </div>

    <div class="controls">
      <button onclick="uploadNow()">📤 Upload to WiGLE</button>
      <button onclick="downloadCSV()">💾 Download CSV</button>
      <button class="danger" onclick="clearData()">🗑️ Clear Data</button>
      <button class="warning" onclick="goToSetup()">⚙️ Settings</button>
    </div>

    <div class="auto-refresh">
      Auto-refreshing every 2 seconds...
    </div>

    <table>
      <thead>
        <tr>
          <th>Time</th>
          <th>MAC Address</th>
          <th>SSID</th>
          <th>RSSI</th>
          <th>Channel</th>
        </tr>
      </thead>
      <tbody id="probeTable">
        <tr><td colspan="5" style="text-align:center;">Loading...</td></tr>
      </tbody>
    </table>
  </div>

  <script>
    function updateData() {
      fetch('/data')
        .then(response => response.json())
        .then(data => {
          document.getElementById('totalProbes').textContent = data.total;
          document.getElementById('memoryProbes').textContent = data.count;
          document.getElementById('uploaded').textContent = data.uploaded;
          document.getElementById('channel').textContent = data.channel;
          document.getElementById('uptime').textContent = formatUptime(data.uptime);
          document.getElementById('lastUpload').textContent = data.lastUpload;
          
          let tableHTML = '';
          if (data.probes.length === 0) {
            tableHTML = '<tr><td colspan="5" style="text-align:center;">No probes captured yet...</td></tr>';
          } else {
            data.probes.forEach(probe => {
              let rssiClass = 'rssi-poor';
              if (probe.rssi > -50) rssiClass = 'rssi-good';
              else if (probe.rssi > -70) rssiClass = 'rssi-medium';
              
              tableHTML += `<tr>
                <td>${formatTime(probe.time)}</td>
                <td class="mac">${probe.mac}</td>
                <td class="ssid">${probe.ssid}</td>
                <td class="rssi ${rssiClass}">${probe.rssi} dBm</td>
                <td>${probe.channel}</td>
              </tr>`;
            });
          }
          document.getElementById('probeTable').innerHTML = tableHTML;
        })
        .catch(err => console.error('Error fetching data:', err));
    }

    function formatTime(ms) {
      let seconds = Math.floor(ms / 1000);
      let minutes = Math.floor(seconds / 60);
      let hours = Math.floor(minutes / 60);
      seconds = seconds % 60;
      minutes = minutes % 60;
      
      if (hours > 0) {
        return `${hours}h ${minutes}m ${seconds}s`;
      } else if (minutes > 0) {
        return `${minutes}m ${seconds}s`;
      } else {
        return `${seconds}s`;
      }
    }

    function formatUptime(ms) {
      let seconds = Math.floor(ms / 1000);
      let minutes = Math.floor(seconds / 60);
      let hours = Math.floor(minutes / 60);
      let days = Math.floor(hours / 24);
      
      hours = hours % 24;
      minutes = minutes % 60;
      seconds = seconds % 60;
      
      if (days > 0) return `${days}d ${hours}h`;
      if (hours > 0) return `${hours}h ${minutes}m`;
      if (minutes > 0) return `${minutes}m ${seconds}s`;
      return `${seconds}s`;
    }

    function uploadNow() {
      if (confirm('Upload current data to WiGLE?')) {
        fetch('/upload')
          .then(response => response.text())
          .then(data => {
            alert(data);
            updateData();
          });
      }
    }

    function clearData() {
      if (confirm('Clear all captured data?')) {
        fetch('/clear')
          .then(response => response.text())
          .then(data => {
            alert(data);
            updateData();
          });
      }
    }

    function downloadCSV() {
      window.location.href = '/data?format=csv';
    }

    function goToSetup() {
      window.location.href = '/setup';
    }

    function toggleSniffing() {
      fetch('/status')
        .then(response => response.json())
        .then(status => {
          if (status.sniffing) {
            // Currently sniffing, so stop it
            if (confirm('Stop sniffing and return to dashboard mode?')) {
              fetch('/stopsniff')
                .then(response => response.text())
                .then(data => {
                  alert(data);
                  setTimeout(() => {
                    window.location.reload();
                  }, 2000);
                });
            }
          } else {
            // Not sniffing, so start it
            if (confirm('Start sniffing mode? The AP will shut down and you will lose connection. The device will automatically return to dashboard mode after 5 minutes.')) {
              fetch('/startsniff')
                .then(response => response.text())
                .then(data => {
                  alert('Sniffing started! AP is shutting down. Wait 5 minutes, then reconnect to view captured probes.');
                })
                .catch(err => {
                  // Expected - connection will be lost
                  alert('Sniffing started! Reconnect in 5 minutes to view data.');
                });
            }
          }
        });
    }

    setInterval(updateData, 2000);
    updateData();
  </script>
</body>
</html>
)rawliteral";
  
  server.send(200, "text/html", html);
}

void handleSetup() {
  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>ESP8266 Setup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background: #1a1a1a;
      color: #e0e0e0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: #2d2d2d;
      padding: 30px;
      border-radius: 10px;
    }
    h1 {
      color: #4CAF50;
      text-align: center;
      margin-bottom: 10px;
    }
    .subtitle {
      text-align: center;
      color: #888;
      margin-bottom: 30px;
    }
    .section {
      margin-bottom: 30px;
      padding: 20px;
      background: #3d3d3d;
      border-radius: 8px;
    }
    .section-title {
      color: #4CAF50;
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 15px;
      border-bottom: 2px solid #4CAF50;
      padding-bottom: 5px;
    }
    label {
      display: block;
      margin-bottom: 5px;
      color: #aaa;
      font-size: 14px;
    }
    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      background: #2d2d2d;
      border: 1px solid #555;
      border-radius: 5px;
      color: #e0e0e0;
      font-size: 14px;
      box-sizing: border-box;
    }
    input:focus {
      outline: none;
      border-color: #4CAF50;
    }
    .hint {
      font-size: 12px;
      color: #888;
      margin-top: -10px;
      margin-bottom: 15px;
    }
    button {
      width: 100%;
      background: #4CAF50;
      color: white;
      border: none;
      padding: 15px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      font-weight: bold;
      margin-top: 10px;
    }
    button:hover {
      background: #45a049;
    }
    button.danger {
      background: #f44336;
      margin-top: 20px;
    }
    button.danger:hover {
      background: #da190b;
    }
    .info-box {
      background: #2d4a2d;
      padding: 15px;
      border-radius: 5px;
      margin-bottom: 20px;
      border-left: 4px solid #4CAF50;
    }
    .warning-box {
      background: #4a3d2d;
      padding: 15px;
      border-radius: 5px;
      margin-top: 20px;
      border-left: 4px solid #ff9800;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>⚙️ ESP8266 Configuration</h1>
    <div class="subtitle">)rawliteral" + String(setupMode ? "Initial Setup Required" : "Update Settings") + R"rawliteral(</div>
    
    <div class="info-box">
      ℹ️ Configure your WiFi and WiGLE credentials below. After saving, the device will restart and begin capturing probe requests.
    </div>
    
    <form action="/save" method="POST">
      <div class="section">
        <div class="section-title">📶 WiFi Settings</div>
        <label>WiFi Network Name (SSID)</label>
        <input type="text" name="wifi_ssid" value=")rawliteral" + String(config.wifi_ssid) + R"rawliteral(" placeholder="Your WiFi Network" required>
        <div class="hint">Your home/office WiFi for uploading to WiGLE</div>
        
        <label>WiFi Password</label>
        <input type="password" name="wifi_password" value=")rawliteral" + String(config.wifi_password) + R"rawliteral(" placeholder="WiFi Password" required>
        <div class="hint">Must have internet access</div>
      </div>
      
      <div class="section">
        <div class="section-title">📡 Access Point Settings</div>
        <label>AP Network Name (SSID)</label>
        <input type="text" name="ap_ssid" value=")rawliteral" + String(config.ap_ssid) + R"rawliteral(" placeholder="ESP8266-ProbeSniff" required>
        <div class="hint">The WiFi network this device creates</div>
        
        <label>AP Password</label>
        <input type="password" name="ap_password" value=")rawliteral" + String(config.ap_password) + R"rawliteral(" placeholder="Minimum 8 characters" minlength="8" required>
        <div class="hint">Password to access the web interface</div>
      </div>
      
      <div class="section">
        <div class="section-title">🌐 WiGLE API Credentials</div>
        <label>API Name</label>
        <input type="text" name="wigle_api_name" value=")rawliteral" + String(config.wigle_api_name) + R"rawliteral(" placeholder="AID..." required>
        <div class="hint">From wigle.net/account</div>
        
        <label>API Token</label>
        <input type="text" name="wigle_api_token" value=")rawliteral" + String(config.wigle_api_token) + R"rawliteral(" placeholder="Your API Token" required>
        <div class="hint">From wigle.net/account</div>
      </div>
      
      <button type="submit">💾 Save and Restart</button>
    </form>
    
    <div class="warning-box">
      ⚠️ After saving, the device will restart with your new settings. Connect to your new AP network to access the dashboard.
    </div>
    
    )rawliteral" + String(!setupMode ? "<button class='danger' onclick=\"if(confirm('Reset to factory defaults? This will erase all settings!')){window.location.href='/reset';}\">🔄 Factory Reset</button>" : "") + R"rawliteral(
  </div>
</body>
</html>
)rawliteral";
  
  server.send(200, "text/html", html);
}

void handleSaveConfig() {
  if (server.hasArg("wifi_ssid")) {
    strncpy(config.wifi_ssid, server.arg("wifi_ssid").c_str(), sizeof(config.wifi_ssid) - 1);
  }
  if (server.hasArg("wifi_password")) {
    strncpy(config.wifi_password, server.arg("wifi_password").c_str(), sizeof(config.wifi_password) - 1);
  }
  if (server.hasArg("ap_ssid")) {
    strncpy(config.ap_ssid, server.arg("ap_ssid").c_str(), sizeof(config.ap_ssid) - 1);
  }
  if (server.hasArg("ap_password")) {
    strncpy(config.ap_password, server.arg("ap_password").c_str(), sizeof(config.ap_password) - 1);
  }
  if (server.hasArg("wigle_api_name")) {
    strncpy(config.wigle_api_name, server.arg("wigle_api_name").c_str(), sizeof(config.wigle_api_name) - 1);
  }
  if (server.hasArg("wigle_api_token")) {
    strncpy(config.wigle_api_token, server.arg("wigle_api_token").c_str(), sizeof(config.wigle_api_token) - 1);
  }
  
  config.configured = true;
  saveConfig();
  
  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>Configuration Saved</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="5;url=/">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background: #1a1a1a;
      color: #e0e0e0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .message {
      text-align: center;
      background: #2d2d2d;
      padding: 40px;
      border-radius: 10px;
      max-width: 500px;
    }
    h1 {
      color: #4CAF50;
      margin-bottom: 20px;
    }
    p {
      font-size: 16px;
      line-height: 1.6;
      color: #aaa;
    }
    .success {
      font-size: 48px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="message">
    <div class="success">✅</div>
    <h1>Configuration Saved!</h1>
    <p>Your settings have been saved successfully.</p>
    <p>The device is restarting now...</p>
    <p><strong>Connect to: )rawliteral" + String(config.ap_ssid) + R"rawliteral(</strong></p>
    <p>Then visit: <strong>http://192.168.4.1</strong></p>
  </div>
</body>
</html>
)rawliteral";
  
  server.send(200, "text/html", html);
  
  delay(2000);
  ESP.restart();
}

void handleReset() {
  resetConfig();
  
  String html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>Factory Reset</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="5;url=/">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background: #1a1a1a;
      color: #e0e0e0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .message {
      text-align: center;
      background: #2d2d2d;
      padding: 40px;
      border-radius: 10px;
      max-width: 500px;
    }
    h1 {
      color: #ff9800;
      margin-bottom: 20px;
    }
    p {
      font-size: 16px;
      line-height: 1.6;
      color: #aaa;
    }
    .icon {
      font-size: 48px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="message">
    <div class="icon">🔄</div>
    <h1>Factory Reset Complete</h1>
    <p>All settings have been erased.</p>
    <p>The device is restarting in setup mode...</p>
    <p><strong>Connect to: )rawliteral" + String(DEFAULT_AP_SSID) + R"rawliteral(</strong></p>
    <p>Password: <strong>)rawliteral" + String(DEFAULT_AP_PASSWORD) + R"rawliteral(</strong></p>
  </div>
</body>
</html>
)rawliteral";
  
  server.send(200, "text/html", html);
  
  delay(2000);
  ESP.restart();
}

void handleData() {
  if (server.hasArg("format") && server.arg("format") == "csv") {
    String csv = generateCSV();
    server.sendHeader("Content-Disposition", "attachment; filename=probes.csv");
    server.send(200, "text/csv", csv);
    return;
  }
  
  String json = "{";
  json += "\"total\":" + String(totalProbesCapture) + ",";
  json += "\"count\":" + String(probeCount) + ",";
  json += "\"uploaded\":" + String(uploadedCount) + ",";
  json += "\"channel\":" + String(currentChannel) + ",";
  json += "\"uptime\":" + String(millis() - startTime) + ",";
  json += "\"lastUpload\":\"" + lastUploadStatus + "\",";
  json += "\"probes\":[";
  
  for (int i = probeCount - 1; i >= 0; i--) {
    if (i < probeCount - 1) json += ",";
    json += "{";
    json += "\"mac\":\"" + probeList[i].mac + "\",";
    json += "\"ssid\":\"" + probeList[i].ssid + "\",";
    json += "\"rssi\":" + String(probeList[i].rssi) + ",";
    json += "\"channel\":" + String(probeList[i].channel) + ",";
    json += "\"time\":" + String(probeList[i].timestamp);
    json += "}";
  }
  
  json += "]}";
  
  server.send(200, "application/json", json);
}

void handleUpload() {
  // Upload only works in dashboard mode (not while sniffing)
  if (isSniffing) {
    server.send(400, "text/plain", "Cannot upload while sniffing. Stop sniffing first.");
    return;
  }
  
  server.send(200, "text/plain", "Starting upload... AP will restart after upload.");
  delay(100);
  
  // Shutdown AP
  server.stop();
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(1000);
  
  // Connect and upload
  if (connectToWiFi()) {
    uploadToWiGLE();
    disconnectWiFi();
  } else {
    lastUploadStatus = "WiFi connection failed";
  }
  
  // Restart dashboard mode
  startDashboardMode();
}

void handleClear() {
  probeCount = 0;
  totalProbesCapture = 0;
  Serial.println("Data cleared via web interface");
  server.send(200, "text/plain", "Data cleared successfully");
}

void handleStartSniffing() {
  server.send(200, "text/plain", "Starting sniffing mode...");
  delay(100);
  startSniffingMode();
}

void handleStopSniffing() {
  stopSniffingMode();
  delay(1000);
  startDashboardMode();
  server.send(200, "text/plain", "Stopped sniffing. Dashboard mode restored.");
}

void handleStatus() {
  String json = "{";
  json += "\"sniffing\":" + String(isSniffing ? "true" : "false") + ",";
  json += "\"uptime\":" + String(millis() - startTime) + ",";
  json += "\"probes\":" + String(probeCount);
  json += "}";
  server.send(200, "application/json", json);
}

// ===== WIFI FUNCTIONS =====
bool connectToWiFi() {
  Serial.println("Connecting to WiFi...");
  WiFi.begin(config.wifi_ssid, config.wifi_password);
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected!");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
    return true;
  } else {
    Serial.println("\nWiFi connection failed!");
    return false;
  }
}

void disconnectWiFi() {
  WiFi.disconnect();
  delay(100);
}

// ===== PROBE MANAGEMENT =====
void addProbe(const String& mac, const String& ssid, int rssi, int channel) {
  if (probeCount >= MAX_PROBES_DISPLAY) {
    for (int i = 0; i < MAX_PROBES_DISPLAY - 1; i++) {
      probeList[i] = probeList[i + 1];
    }
    probeCount = MAX_PROBES_DISPLAY - 1;
  }
  
  probeList[probeCount].mac = mac;
  probeList[probeCount].ssid = ssid;
  probeList[probeCount].rssi = rssi;
  probeList[probeCount].channel = channel;
  probeList[probeCount].timestamp = millis() - startTime;
  
  probeCount++;
  totalProbesCapture++;
}

// ===== SNIFFER CALLBACK =====
void snifferCallback(uint8_t *buffer, uint16_t length) {
  if (length < sizeof(struct RxControl)) return;
  
  struct SnifferPacket *snifferPacket = (struct SnifferPacket*) buffer;
  
  // Get frame control field (first 2 bytes)
  uint8_t frameControl = snifferPacket->data[0];
  uint8_t frameType = (frameControl & 0x0C) >> 2;  // Bits 2-3
  uint8_t frameSubType = (frameControl & 0xF0) >> 4;  // Bits 4-7
  
  // Only process management frames (type 0) with probe request subtype (4)
  if (frameType != 0 || frameSubType != 4) {
    return;
  }
  
  // Source MAC address is at offset 10 (sender of probe request)
  uint8_t srcMAC[6];
  for (int i = 0; i < 6; i++) {
    srcMAC[i] = snifferPacket->data[10 + i];
  }
  
  // Get our own MAC address to filter it out
  uint8_t ownMAC[6];
  WiFi.macAddress(ownMAC);
  
  // Skip if this is from our own device
  bool isOwnMAC = true;
  for (int i = 0; i < 6; i++) {
    if (srcMAC[i] != ownMAC[i]) {
      isOwnMAC = false;
      break;
    }
  }
  if (isOwnMAC) return;
  
  // Parse SSID from probe request
  // Probe request frame structure:
  // [Frame Control (2)][Duration (2)][DA (6)][SA (6)][BSSID (6)][Seq Control (2)][Tagged Parameters...]
  // Total fixed header = 24 bytes, then tagged parameters start
  
  String ssid = "";
  int ssidLen = 0;
  
  // Tagged parameters start at offset 24
  // First tagged parameter should be SSID (tag 0)
  if (length > 25) {
    uint8_t tagNumber = snifferPacket->data[24];
    uint8_t tagLength = snifferPacket->data[25];
    
    // Verify this is SSID tag (0) and length is reasonable
    if (tagNumber == 0 && tagLength > 0 && tagLength <= 32 && (26 + tagLength) <= length) {
      ssidLen = tagLength;
      char ssidBuf[33];
      for (int i = 0; i < ssidLen; i++) {
        ssidBuf[i] = snifferPacket->data[26 + i];
      }
      ssidBuf[ssidLen] = '\0';
      ssid = String(ssidBuf);
      
      // Validate SSID contains printable characters
      bool validSSID = true;
      for (int i = 0; i < ssidLen; i++) {
        if (ssidBuf[i] < 32 || ssidBuf[i] > 126) {
          validSSID = false;
          break;
        }
      }
      if (!validSSID) {
        ssid = "";
      }
    }
  }
  
  int rssi = snifferPacket->rx_ctrl.rssi;
  int channel = snifferPacket->rx_ctrl.channel;
  String macStr = macToString(srcMAC);
  
  // Capture both directed probes (with SSID) and broadcast probes (empty SSID)
  if (ssid.length() > 0) {
    // Directed probe - device looking for specific network
    Serial.print("PROBE: ");
    Serial.print(macStr);
    Serial.print(" -> ");
    Serial.print(ssid);
    Serial.print(" (RSSI: ");
    Serial.print(rssi);
    Serial.print(" dBm, CH: ");
    Serial.print(channel);
    Serial.println(")");
    
    addProbe(macStr, ssid, rssi, channel);
  } else {
    // Broadcast probe - device scanning for any network
    Serial.print("PROBE: ");
    Serial.print(macStr);
    Serial.print(" -> <broadcast>");
    Serial.print(" (RSSI: ");
    Serial.print(rssi);
    Serial.print(" dBm, CH: ");
    Serial.print(channel);
    Serial.println(")");
    
    addProbe(macStr, "<broadcast>", rssi, channel);
  }
}

// ===== CSV GENERATION =====
String generateCSV() {
  String csv = "WigleWifi-1.6,appRelease=2.0,model=ESP8266,release=1.0,device=ESP8266,display=WebUI,board=ESP8266,brand=Espressif,star=Sol,body=3,subBody=0\n";
  csv += "MAC,SSID,AuthMode,FirstSeen,Channel,Frequency,RSSI,CurrentLatitude,CurrentLongitude,AltitudeMeters,AccuracyMeters,RCOIs,MfgrId,Type\n";
  
  for (int i = 0; i < probeCount; i++) {
    int frequency = 2407 + (probeList[i].channel * 5);
    csv += probeList[i].mac + ",";
    csv += probeList[i].ssid + ",";
    csv += "[PROBE],";
    csv += "2026-01-01 00:00:00,";
    csv += String(probeList[i].channel) + ",";
    csv += String(frequency) + ",";
    csv += String(probeList[i].rssi) + ",";
    csv += "0.0,0.0,0,0,,,WIFI\n";
  }
  
  return csv;
}

// ===== UPLOAD FUNCTION =====
void uploadToWiGLE() {
  if (probeCount == 0) {
    Serial.println("No records to upload.");
    lastUploadStatus = "No data to upload";
    return;
  }
  
  Serial.print("Uploading ");
  Serial.print(probeCount);
  Serial.println(" records to WiGLE...");
  
  WiFiClientSecure client;
  client.setInsecure();
  
  HTTPClient http;
  
  String url = "https://api.wigle.net/api/v2/file/upload";
  
  if (http.begin(client, url)) {
    
    String auth = String(config.wigle_api_name) + ":" + String(config.wigle_api_token);
    String authEncoded = base64Encode(auth);
    http.addHeader("Authorization", "Basic " + authEncoded);
    
    String boundary = "----ESP8266Boundary";
    String contentType = "multipart/form-data; boundary=" + boundary;
    http.addHeader("Content-Type", contentType);
    
    String csvData = generateCSV();
    
    String body = "";
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"file\"; filename=\"esp8266_probes.csv\"\r\n";
    body += "Content-Type: text/csv\r\n\r\n";
    body += csvData;
    body += "\r\n--" + boundary + "--\r\n";
    
    int httpCode = http.POST(body);
    
    if (httpCode > 0) {
      Serial.print("HTTP Response code: ");
      Serial.println(httpCode);
      
      String response = http.getString();
      Serial.println("Response:");
      Serial.println(response);
      
      if (httpCode == 200) {
        Serial.println("Upload successful!");
        lastUploadStatus = "Success! Uploaded " + String(probeCount) + " probes";
        uploadedCount += probeCount;
        probeCount = 0;
      } else {
        Serial.println("Upload failed!");
        lastUploadStatus = "Failed: HTTP " + String(httpCode);
      }
    } else {
      Serial.print("HTTP Error: ");
      Serial.println(http.errorToString(httpCode));
      lastUploadStatus = "Error: " + http.errorToString(httpCode);
    }
    
    http.end();
  } else {
    Serial.println("Unable to connect to WiGLE API");
    lastUploadStatus = "Connection failed";
  }
}

// ===== UTILITY FUNCTIONS =====
void hopChannel() {
  currentChannel++;
  if (currentChannel > 13) {
    currentChannel = 1;
  }
  wifi_set_channel(currentChannel);
}

String macToString(const uint8_t* mac) {
  char buf[18];
  sprintf(buf, "%02X:%02X:%02X:%02X:%02X:%02X", 
          mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(buf);
}

String base64Encode(const String& input) {
  const char* chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  String output = "";
  int val = 0;
  int valb = -6;
  
  for (unsigned char c : input) {
    val = (val << 8) + c;
    valb += 8;
    while (valb >= 0) {
      output += chars[(val >> valb) & 0x3F];
      valb -= 6;
    }
  }
  
  if (valb > -6) {
    output += chars[((val << 8) >> (valb + 8)) & 0x3F];
  }
  
  while (output.length() % 4) {
    output += '=';
  }
  
  return output;
}
