# ESP8266 WiGLE Probe Sniffer - Web Configuration Version

**Flash once, configure anywhere!** This version allows you to flash a generic .bin file and configure all settings (WiFi, WiGLE API) through a web interface after flashing.

## 🌟 Key Features

### ✅ No Pre-Configuration Needed
- Flash the **same .bin file** on any ESP8266
- Configure settings **after flashing** via web browser
- Settings stored in **EEPROM** (persist across reboots)
- **Factory reset** option to reconfigure anytime

### 📱 Web-Based Setup
- Beautiful setup page on first boot
- Configure WiFi credentials
- Configure WiGLE API keys
- Customize Access Point name/password
- All from your browser!

### 🎯 Full Feature Set
- Real-time probe request capture
- Live web dashboard with statistics
- One-click WiGLE upload
- CSV download
- Auto-refreshing interface
- Mobile responsive
- Dark theme

## 🚀 Quick Start Guide

### Step 1: Flash the Firmware

Use your preferred flashing tool:

#### ESP Flash Download Tool (Windows)
1. Download from [Espressif](https://www.espressif.com/en/support/download/other-tools)
2. Select "ESP8266 DownloadTool"
3. Add `esp8266_wigle_READY_TO_FLASH.bin` at address `0x00000`
4. Select your COM port
5. Click START

#### esptool.py (Command Line)
```bash
esptool.py --port /dev/ttyUSB0 --baud 115200 write_flash 0x00000 esp8266_wigle_READY_TO_FLASH.bin
```

#### Arduino IDE
1. Open Arduino IDE
2. Copy contents of `src/main.cpp` into a new sketch
3. Select your ESP8266 board
4. Click Upload

### Step 2: Initial Setup

After flashing, the ESP8266 will boot in **SETUP MODE**:

1. **Look for WiFi network**: `ESP8266-Setup`
2. **Connect** with password: `setup123`
3. **Open browser**: http://192.168.4.1
4. **Fill in the setup form**:
   - Your WiFi network name and password
   - Your WiGLE API Name and Token (from wigle.net/account)
   - Custom Access Point name/password (optional)
5. **Click "Save and Restart"**

### Step 3: Use the Dashboard

After the device restarts:

1. **Connect to your custom AP** (the one you configured)
2. **Open browser**: http://192.168.4.1
3. **Watch probes** appear in real-time!
4. **Upload to WiGLE** with one click

## 📋 Setup Form Fields

### WiFi Settings
| Field | Description | Example |
|-------|-------------|---------|
| **WiFi SSID** | Your home/office WiFi network | `MyHomeNetwork` |
| **WiFi Password** | Password for your WiFi | `MyPassword123` |

*This WiFi must have internet access to upload to WiGLE*

### Access Point Settings
| Field | Description | Example |
|-------|-------------|---------|
| **AP SSID** | Name of the WiFi network the ESP8266 creates | `ProbeMonitor` |
| **AP Password** | Password to access the dashboard (min 8 chars) | `MyDashboard2026` |

*You'll connect to this network to view the web interface*

### WiGLE API Credentials
| Field | Description | Where to Get |
|-------|-------------|--------------|
| **API Name** | Your WiGLE API identifier | https://wigle.net/account |
| **API Token** | Your WiGLE API authentication token | https://wigle.net/account |

*Required for uploading data to WiGLE*

## 🔧 How It Works

### First Boot (Setup Mode)
1. ESP8266 checks EEPROM for configuration
2. If not configured, creates `ESP8266-Setup` WiFi network
3. Displays setup page at http://192.168.4.1
4. Saves your settings to EEPROM
5. Restarts in normal mode

### Normal Operation
1. ESP8266 creates your custom Access Point
2. Starts capturing probe requests
3. Web dashboard available at http://192.168.4.1
4. Settings persist across power cycles

### Configuration Storage
- Settings stored in **EEPROM** (512 bytes)
- Survives power loss and reboots
- Can be reset to factory defaults anytime

## 🎨 Web Interface Features

### Setup Page
- Clean, modern design
- Form validation
- Helpful hints for each field
- Confirmation before restart
- Factory reset option (after initial setup)

### Dashboard
- **Statistics**: Total captured, in memory, uploaded, channel, uptime
- **Live table**: Recent probe requests with MAC, SSID, RSSI, channel
- **Controls**: Upload, Download CSV, Clear Data, Settings
- **Auto-refresh**: Updates every 2 seconds
- **Color-coded RSSI**: Green (strong), Orange (medium), Red (weak)

## ⚙️ Settings Management

### Accessing Settings
From the dashboard, click the **"⚙️ Settings"** button to:
- View current configuration
- Update WiFi credentials
- Change Access Point name/password
- Update WiGLE API keys
- Factory reset

### Factory Reset
1. Go to Settings page
2. Click **"🔄 Factory Reset"**
3. Confirm the action
4. Device erases all settings
5. Reboots in setup mode
6. Connect to `ESP8266-Setup` again

## 📱 Serial Monitor Output

Connect at 115200 baud to see status messages:

### Setup Mode
```
=================================
ESP8266 WiGLE Probe Sniffer
Web Config Version
=================================

⚠️  Device not configured!
Starting in SETUP MODE...

Setup Access Point started!
SSID: ESP8266-Setup
Password: setup123
IP: 192.168.4.1

📱 Connect to this WiFi and visit: http://192.168.4.1
   Configure your settings, then the device will restart.
```

### Normal Mode
```
=================================
ESP8266 WiGLE Probe Sniffer
Web Config Version
=================================

Configuration loaded from EEPROM
✅ Device configured!
Starting in NORMAL MODE...

Access Point started!
AP SSID: MyProbeMonitor
AP Password: ********
AP IP: 192.168.4.1

📱 Connect to the AP and visit: http://192.168.4.1

Web server started!
Started sniffing probe requests...
Channels: 1-13

PROBE: A4:83:E7:12:34:56 -> HomeNetwork (RSSI: -45 dBm, CH: 6)
```

## 🔒 Security Considerations

### EEPROM Storage
- All settings stored in plain text in EEPROM
- WiFi passwords and API tokens are **not encrypted**
- Physical access to ESP8266 = access to credentials
- Consider this when choosing passwords

### Access Point Security
- Default setup password is weak (`setup123`)
- Anyone in range can connect during setup
- Change AP password to something strong
- Setup mode only occurs on first boot or after factory reset

### Recommendations
1. **Complete setup quickly** to minimize exposure
2. **Use a strong AP password** (12+ characters)
3. **Don't use your main WiFi password** as the AP password
4. **Keep the device physically secure**
5. **Factory reset** if device changes hands

## 🐛 Troubleshooting

### Can't Find ESP8266-Setup Network

**Check:**
- ESP8266 is powered on
- Wait 30 seconds after power-on
- Look for exact name: `ESP8266-Setup`

**Try:**
- Restart the ESP8266
- Check serial monitor for errors
- Re-flash the firmware

### Can't Access Setup Page

**Check:**
- Connected to `ESP8266-Setup` WiFi
- Using `http://` not `https://`
- Correct IP: `192.168.4.1`

**Try:**
- Disable mobile data on phone
- Try different browser
- Check WiFi connection status

### Settings Not Saving

**Check:**
- All required fields filled
- AP password at least 8 characters
- No special characters causing issues

**Try:**
- Simplify passwords (alphanumeric only)
- Check serial monitor for errors
- Factory reset and try again

### Device Stuck in Setup Mode

**Possible causes:**
- EEPROM corruption
- Incomplete save operation
- Power loss during save

**Solution:**
- Factory reset via web interface
- Or re-flash the firmware

### Upload to WiGLE Fails

**Check:**
- WiFi credentials correct
- WiFi has internet access
- WiGLE API credentials valid
- Serial monitor for specific errors

**Try:**
- Test WiFi on another device
- Verify API keys at wigle.net/account
- Download CSV and upload manually

## 💡 Advanced Tips

### Multiple Devices
- Flash the same .bin to multiple ESP8266s
- Configure each with different AP names
- Deploy a network of sniffers
- Each stores its own configuration

### Backup Configuration
- Settings stored in EEPROM addresses 0-511
- Can be read via serial tools
- No built-in export feature (yet)
- Write down your settings manually

### Changing Settings
- No need to re-flash to change settings
- Just visit the Settings page
- Update any field
- Device restarts with new config

### Development Mode
- Serial monitor shows detailed debug info
- Useful for troubleshooting
- Shows all probe requests in real-time
- Displays WiFi connection attempts

## 📊 Technical Details

### EEPROM Layout
```
Offset 0: Magic byte (0xAB)
Offset 1-64: WiFi SSID
Offset 65-128: WiFi Password
Offset 129-160: AP SSID
Offset 161-192: AP Password
Offset 193-256: WiGLE API Name
Offset 257-320: WiGLE API Token
Offset 321: Configured flag
```

### Memory Usage
- **RAM**: 64.6% (52,896 bytes)
- **Flash**: 41.4% (432,135 bytes)
- **EEPROM**: 512 bytes allocated
- **Probe storage**: Up to 200 probes in RAM

### WiFi Modes
- **Setup Mode**: AP only (192.168.4.1)
- **Normal Mode**: AP + STA (dual mode)
- Seamless mode switching
- No manual intervention needed

## 🎓 Use Cases

### Personal Use
- Flash once, configure at home
- Take anywhere for portable monitoring
- Reconfigure for different locations
- No laptop needed for setup

### Multiple Deployments
- Flash many devices with same firmware
- Configure each on-site
- Different AP names for identification
- Centralized firmware management

### Research Projects
- Standard firmware for all participants
- Each configures their own credentials
- Consistent behavior across devices
- Easy to redeploy

### Educational Settings
- Students flash same firmware
- Each configures their own WiGLE account
- No source code editing required
- Focus on usage, not compilation

## 📦 File Structure

```
esp8266_wigle_webconfig/
├── src/
│   └── main.cpp                        # Full source code
├── platformio.ini                      # Build configuration
├── README.md                           # This file
├── QUICKSTART.md                       # Quick setup guide
├── FLASHING_GUIDE.md                   # Detailed flashing instructions
└── esp8266_wigle_READY_TO_FLASH.bin   # Ready-to-flash firmware
```

## 🆚 Comparison with Other Versions

| Feature | Web Config | Pre-Config | Serial Only |
|---------|------------|------------|-------------|
| **Pre-compilation config** | ❌ No | ✅ Yes | ✅ Yes |
| **Post-flash config** | ✅ Yes | ❌ No | ❌ No |
| **Web interface** | ✅ Yes | ✅ Yes | ❌ No |
| **Settings page** | ✅ Yes | ❌ No | ❌ No |
| **Factory reset** | ✅ Yes | ❌ No | ❌ No |
| **Ease of deployment** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ |
| **Reconfiguration** | ⭐⭐⭐⭐⭐ | ⭐ | ⭐ |

## 🔄 Updating Firmware

To update to a newer version:

1. **Backup your settings** (write them down)
2. **Flash new firmware**
3. **Device will boot in setup mode**
4. **Re-enter your settings**
5. **Continue using**

*Settings are not preserved across firmware updates*

## ⚖️ Legal & Privacy

- Captures **publicly broadcast** WiFi probe requests
- Modern devices use MAC randomization
- Use responsibly and check local laws
- Educational and research purposes only
- WiGLE data used for network mapping

## 🤝 Contributing Ideas

Potential enhancements:
- Configuration export/import
- Multiple WiFi network support
- Scheduled automatic uploads
- GPS module integration
- OTA (Over-The-Air) firmware updates
- Configuration backup to file

## 📚 Resources

- **WiGLE**: https://wigle.net
- **ESP8266 Arduino**: https://arduino-esp8266.readthedocs.io/
- **PlatformIO**: https://platformio.org
- **Probe Requests**: https://en.wikipedia.org/wiki/Probe_request

## 📄 License

Educational use only. Use responsibly and in accordance with local laws.

---

**Version**: 3.0 (Web Configuration)  
**Last Updated**: February 2026  
**Compatible Hardware**: ESP8266 (NodeMCU, D1 Mini, Wemos D1, etc.)  
**Firmware Size**: 427 KB  
**Configuration**: Post-flash via web interface
